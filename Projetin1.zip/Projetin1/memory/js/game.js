// Referências aos elementos do DOM
const grid = document.querySelector('.grid');
const playerNickSpan = document.getElementById('player-nick');
const gameTimerSpan = document.getElementById('game-timer');
const gameOverScreenGame = document.getElementById('game-over-screen-game');
const finalGameTimeSpan = document.getElementById('final-game-time');
const playAgainButton = document.getElementById('play-again-btn');
const loadingScreen = document.getElementById('loading-screen'); // NOVO: Referência à tela de carregamento
const gameContainer = document.querySelector('.game'); // NOVO: Referência ao container do jogo

// Referências aos elementos de áudio
const gameThemeAudio = document.getElementById('game-theme-audio');
const cardRevealAudio = document.getElementById('card-reveal-audio');
const matchAudio = document.getElementById('match-audio');
const noMatchAudio = document.getElementById('no-match-audio');
const winAudio = document.getElementById('win-audio');

// Personagens (cartas) do jogo
const characters = [
    'beth',
    'jerry',
    'jessica',
    'morty',
    'pessoa-passaro',
    'pickle-rick',
    'rick',
    'summer',
    'meeseeks',
    'scroopy',
];

// Variáveis de estado do jogo
let firstCard = '';
let secondCard = '';
let gameLoopInterval;
let secondsElapsed = 0;
let matchesFound = 0;

// Funções de Utilitário
const createElement = (tag, className) => {
    const element = document.createElement(tag);
    element.className = className;
    return element;
};

const formatTime = (totalSeconds) => {
    const minutes = Math.floor(totalSeconds / 60);
    const remainingSeconds = totalSeconds % 60;
    const paddedMinutes = String(minutes).padStart(2, '0');
    const paddedSeconds = String(remainingSeconds).padStart(2, '0');
    return `${paddedMinutes}:${paddedSeconds}`;
};

// Lógica do Cronômetro
const startTimer = () => {
    secondsElapsed = 0;
    gameTimerSpan.textContent = formatTime(secondsElapsed);
    if (gameLoopInterval) clearInterval(gameLoopInterval);

    gameLoopInterval = setInterval(() => {
        secondsElapsed++;
        gameTimerSpan.textContent = formatTime(secondsElapsed);
    }, 1000);
};

const stopTimer = () => {
    clearInterval(gameLoopInterval);
};

// Lógica do Jogo
const checkEndGame = () => {
    if (matchesFound === characters.length) {
        stopTimer();
        gameThemeAudio.pause();
        gameThemeAudio.currentTime = 0;
        winAudio.play().catch(e => console.warn("Erro ao tocar áudio de vitória:", e));

        finalGameTimeSpan.textContent = formatTime(secondsElapsed);
        gameOverScreenGame.classList.add('active');
    }
};

const checkCards = () => {
    const firstCharacter = firstCard.getAttribute('data-character');
    const secondCharacter = secondCard.getAttribute('data-character');

    if (firstCharacter === secondCharacter) {
        firstCard.classList.add('disabled-card'); // Aplica no elemento 'card' pai
        secondCard.classList.add('disabled-card');
        matchAudio.play().catch(e => console.warn("Erro ao tocar áudio de acerto:", e));
        
        matchesFound++;
        checkEndGame();

        firstCard = '';
        secondCard = '';

    } else {
        noMatchAudio.play().catch(e => console.warn("Erro ao tocar áudio de erro:", e));
        setTimeout(() => {
            firstCard.classList.remove('reveal-card');
            secondCard.classList.remove('reveal-card');

            firstCard = '';
            secondCard = '';

        }, 800);
    }
};

const revealCard = ({ target }) => {
    if (target.parentNode.classList.contains('reveal-card') || secondCard !== '') {
        return;
    }

    cardRevealAudio.currentTime = 0;
    cardRevealAudio.play().catch(e => console.warn("Erro ao tocar áudio de virar carta:", e));

    if (firstCard === '') {
        target.parentNode.classList.add('reveal-card');
        firstCard = target.parentNode;

    } else {
        target.parentNode.classList.add('reveal-card');
        secondCard = target.parentNode;
        checkCards();
    }
};

const createCard = (character) => {
    const card = createElement('div', 'card');
    const front = createElement('div', 'face front');
    const back = createElement('div', 'face back');

    front.style.backgroundImage = `url('./images/${character}.png')`;

    card.appendChild(front);
    card.appendChild(back);

    card.addEventListener('click', revealCard);
    card.setAttribute('data-character', character);
    card.setAttribute('aria-label', `Carta com personagem ${character}`);

    return card;
};

const loadGame = () => {
    grid.innerHTML = ''; // Limpa o grid
    matchesFound = 0; // Reseta o contador de pares
    
    // Duplica os personagens e embaralha
    const duplicateCharacters = [...characters, ...characters];
    const shuffledArray = duplicateCharacters.sort(() => Math.random() - 0.5);

    // Cria e adiciona as cartas
    shuffledArray.forEach((character) => {
        const card = createCard(character);
        grid.appendChild(card);
    });
};

// Lógica de áudio para loop da música tema
const startAudioLoop = () => {
    gameThemeAudio.play().catch(() => {
        const playOnInteraction = () => {
            gameThemeAudio.play();
            document.body.removeEventListener('click', playOnInteraction);
            document.body.removeEventListener('keydown', playOnInteraction);
            document.body.removeEventListener('touchstart', playOnInteraction);
        };
        document.body.addEventListener('click', playOnInteraction, { once: true });
        document.body.addEventListener('keydown', playOnInteraction, { once: true });
        document.body.addEventListener('touchstart', playOnInteraction, { once: true });
        console.warn("Música tema bloqueada. Clicar ou interagir para iniciar.");
    });
};

// Event Listener para Jogar Novamente
playAgainButton.addEventListener('click', () => {
    gameOverScreenGame.classList.remove('active');
    loadGame();
    startTimer();
    startAudioLoop();
});


// Inicialização ao carregar a janela
window.onload = () => {
    // Esconde o container do jogo inicialmente para a tela de carregamento
    gameContainer.style.opacity = '0'; 
    gameContainer.style.pointerEvents = 'none'; // Impede interação enquanto invisível

    // Simula um tempo de carregamento mínimo (ex: 2 segundos) ou espera por recursos
    const minLoadingTime = 2000; // 2 segundos
    const startTime = Date.now();

    // Carrega áudios e imagens (se houver, pode-se usar Promise.all para esperar)
    Promise.all([
        // Carrega áudios
        gameThemeAudio.load(),
        cardRevealAudio.load(),
        matchAudio.load(),
        noMatchAudio.load(),
        winAudio.load(),
        // Pode-se carregar imagens dinamicamente aqui também, se for o caso
    ]).then(() => {
        const endTime = Date.now();
        const timeToWait = minLoadingTime - (endTime - startTime);

        setTimeout(() => {
            // Esconde a tela de carregamento
            loadingScreen.style.opacity = '0';
            loadingScreen.addEventListener('transitionend', () => {
                loadingScreen.style.display = 'none'; // Remove do fluxo após a transição
                // Revela o jogo
                gameContainer.style.opacity = '1';
                gameContainer.style.pointerEvents = 'auto'; // Permite interação
            }, { once: true });

            // Inicia o jogo APÓS o carregamento e a transição
            const usuarioLogado = JSON.parse(localStorage.getItem('usuarioLogado'));
            
            if (usuarioLogado && usuarioLogado.nick) {
                playerNickSpan.innerHTML = usuarioLogado.nick;
            } else {
                alert('Você precisa estar logado para jogar!');
                window.location.href = '../login.html';
                return;
            }
            
            loadGame();
            startTimer();
            startAudioLoop();

        }, Math.max(0, timeToWait)); // Garante que espere o tempo mínimo
    }).catch(error => {
        console.error("Erro ao carregar recursos do jogo:", error);
        alert("Erro ao carregar o jogo. Por favor, tente novamente.");
        // Opcional: redirecionar para a página anterior ou exibir uma mensagem de erro mais amigável
        window.location.href = '../jogos.html';
    });
};