// Pega os elementos
const mostrarNick = document.getElementById('mostrarNick');
const btnVoltar = document.getElementById('btnVoltar');

// Busca o jogador salvo
const player = localStorage.getItem('player');

// Se tiver player, mostra o nome. Se não, mostra Visitante.
if (player && player.trim() !== '') {
  mostrarNick.textContent = player;
} else {
  mostrarNick.textContent = 'Visitante';
}

// Botão voltar redireciona para jogos.php
btnVoltar.addEventListener('click', () => {
  window.location.href = '../jogos.php'; // Ajuste o caminho relativo conforme sua pasta
});
