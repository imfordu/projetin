// Referências aos elementos do DOM
const mario = document.querySelector('.mario');
const pipe = document.querySelector('.pipe');
const clouds = document.querySelector('.clouds');
const startScreen = document.getElementById('start-screen');
const startButton = document.getElementById('start-btn');
const gameOverScreen = document.getElementById('game-over-screen');
const restartButton = document.getElementById('restart-btn');

// Elementos do Painel de Informações
const playerNickSpan = document.getElementById('player-nick');
const currentScoreSpan = document.getElementById('current-score');
const gameTimeSpan = document.getElementById('game-time');

// Elementos da Tela de Game Over
const finalScoreSpan = document.getElementById('final-score');
const finalTimeSpan = document.getElementById('final-time');

// Referências à tela de carregamento e ao container do jogo
const loadingScreen = document.getElementById('loading-screen');
const gameContainer = document.querySelector('.game-container');


// Referências aos elementos de áudio
const audioTheme = document.getElementById('audio-theme');
const audioGameOver = document.getElementById('audio-gameover');
const audioJump = document.getElementById('audio-jump');

// Variáveis de estado do jogo
let isJumping = false;
let isGameOver = true;
let marioBottom = 0;
let verticalVelocity = 0;

// AJUSTES DA FÍSICA E DIFICULDADE:
const gravity = 0.6; 
const jumpStrength = 15; 

// Velocidade inicial do cano
let pipeAnimationSpeed = 2.0;

let gameInterval;
let score = 0;
let scoreInterval;
let gameTimerInterval;
let seconds = 0;

// Função para formatar o tempo (MM:SS)
function formatTime(totalSeconds) {
    const minutes = Math.floor(totalSeconds / 60);
    const remainingSeconds = totalSeconds % 60;
    const paddedMinutes = String(minutes).padStart(2, '0');
    const paddedSeconds = String(remainingSeconds).padStart(2, '0');
    return `${paddedMinutes}:${paddedSeconds}`;
}

// Função para iniciar o cronômetro
const startTimer = () => {
    seconds = 0;
    gameTimeSpan.textContent = formatTime(seconds);
    if (gameTimerInterval) clearInterval(gameTimerInterval);

    gameTimerInterval = setInterval(() => {
        seconds++;
        gameTimeSpan.textContent = formatTime(seconds);
    }, 1000);
};

// Função para iniciar o jogo
const startGame = () => {
    if (!isGameOver) return;

    isGameOver = false;
    score = 0;
    currentScoreSpan.textContent = score;

    // Reseta a velocidade inicial do cano para cada novo jogo
    pipeAnimationSpeed = 2.0;
    pipe.style.setProperty('--pipe-speed', `${pipeAnimationSpeed}s`);

    // Oculta telas de overlay
    startScreen.style.opacity = '0';
    startScreen.addEventListener('transitionend', () => {
        startScreen.style.display = 'none';
    }, { once: true });

    gameOverScreen.style.display = 'none';
    gameOverScreen.style.opacity = '0';

    // Reseta posições e estados do Mario
    mario.src = 'img/mario.gif';
    mario.style.width = '150px';
    mario.style.marginLeft = '0px';
    marioBottom = 0;
    mario.style.bottom = marioBottom + 'px';
    isJumping = false;
    verticalVelocity = 0;

    // Aplica animação ao cano
    pipe.classList.add('pipe-animation');
    pipe.style.left = '';

    // Toca a música tema
    audioTheme.currentTime = 0;
    audioTheme.play().catch(e => console.warn("Música tema não pôde ser reproduzida automaticamente.", e));

    // INICIA TODOS OS LOOPS PRINCIPAIS
    gameLoop();
    startScoreCounter();
    startTimer();
};

// Função para reiniciar o jogo (chamada após Game Over)
const restartGame = () => {
    gameOverScreen.style.opacity = '0';
    gameOverScreen.addEventListener('transitionend', () => {
        gameOverScreen.style.display = 'none';
        startGame();
    }, { once: true });
};

// Função de pulo
const jump = () => {
    if (isGameOver || isJumping) return;

    isJumping = true;
    verticalVelocity = jumpStrength;

    audioJump.currentTime = 0;
    audioJump.play().catch(e => console.warn("Som de pulo não pôde ser reproduzido.", e));
};

// Loop principal do jogo
const gameLoop = () => {
    if (gameInterval) clearInterval(gameInterval);

    gameInterval = setInterval(() => {
        if (isGameOver) {
            clearInterval(gameInterval);
            return;
        }

        // --- Lógica do Pulo e Gravidade ---
        marioBottom += verticalVelocity;
        verticalVelocity -= gravity;

        if (marioBottom <= 0) {
            marioBottom = 0;
            isJumping = false;
            verticalVelocity = 0;
        }
        mario.style.bottom = marioBottom + 'px';

        // --- Lógica de Colisão ---
        const pipeLeft = pipe.offsetLeft;
        const marioBottomValue = parseInt(mario.style.bottom);
        const marioRight = mario.offsetLeft + mario.offsetWidth;
        const marioLeft = mario.offsetLeft;

        const marioCollisionHeight = 80; // Ponto de colisão vertical (80px do chão)
        const OFFSET_MARIO_DIREITA = 25; // Distância do lado direito do Mario para a detecção de colisão
        const OFFSET_MARIO_ESQUERDA = 25; // Distância do lado esquerdo do Mario para a detecção de colisão

        const horizontalCollision = pipeLeft <= (marioRight - OFFSET_MARIO_DIREITA) &&
                                    (pipeLeft + pipe.offsetWidth) >= (marioLeft + OFFSET_MARIO_ESQUERDA);
        const verticalCollision = marioBottomValue < marioCollisionHeight;


        if (horizontalCollision && verticalCollision) {
            // Game Over
            clearInterval(gameInterval);
            clearInterval(scoreInterval);
            clearInterval(gameTimerInterval);
            isGameOver = true;

            // Para a animação do cano na posição de colisão
            pipe.classList.remove('pipe-animation');
            pipe.style.left = `${pipeLeft}px`;

            // Muda a imagem e tamanho do Mario para a de Game Over
            mario.src = 'img/game-over.png';
            mario.style.width = '75px';
            mario.style.marginLeft = '50px';

            // Para e toca os áudios
            audioTheme.pause();
            audioTheme.currentTime = 0;
            audioJump.pause();
            audioGameOver.currentTime = 0;
            audioGameOver.play().catch(e => console.warn("Som de Game Over não pôde ser reproduzido.", e));

            // Exibe informações na tela de Game Over
            finalScoreSpan.textContent = score;
            finalTimeSpan.textContent = formatTime(seconds);
            gameOverScreen.style.display = 'flex';
            setTimeout(() => gameOverScreen.style.opacity = '1', 50);
        }

        // --- Aumenta a velocidade do cano gradualmente (dificuldade) ---
        if (score > 0 && score % 100 === 0 && pipeAnimationSpeed > 0.8) {
            pipeAnimationSpeed -= 0.05;
            pipe.style.setProperty('--pipe-speed', `${pipeAnimationSpeed}s`);
            console.log(`Dificuldade aumentada! Nova velocidade do cano: ${pipeAnimationSpeed.toFixed(2)}s`);
        }

    }, 20); // Intervalo de atualização do gameLoop em 20ms
};

// Funções de Pontuação
const startScoreCounter = () => {
    if (scoreInterval) clearInterval(scoreInterval);

    score = 0;
    scoreInterval = setInterval(() => {
        score += 1;
        currentScoreSpan.textContent = score;
    }, 100);
};


// --- Event Listeners ---
startButton.addEventListener('click', startGame);
restartButton.addEventListener('click', restartGame);

document.addEventListener('keydown', e => {
    if (e.key === ' ' || e.code === 'Space') {
        e.preventDefault();
        if (isGameOver) {
            startGame();
        } else {
            jump();
        }
    }
});

document.addEventListener('touchstart', e => {
    if (e.touches.length > 0) {
        if (isGameOver) {
            startGame();
        } else {
            e.preventDefault();
            jump();
        }
    }
});

// Inicialização ao carregar a janela
document.addEventListener('DOMContentLoaded', () => {
    // Oculta o container do jogo inicialmente para a tela de carregamento
    gameContainer.style.opacity = '0';
    gameContainer.style.pointerEvents = 'none'; // Impede interação enquanto invisível

    // NOVO: Duração da tela de carregamento
    const minLoadingTime = 10000; // 10 segundos

    const startTime = Date.now();

    // Cria um array de Promises para carregar todos os recursos
    const resourcePromises = [];

    const loadResource = (element) => {
        return new Promise(resolve => {
            const onError = () => {
                console.error(`Erro ao carregar recurso: ${element.src || element.id || 'Unknown'}`);
                resolve(); // Resolve mesmo no erro para não travar o carregamento
            };
            const onLoad = () => {
                resolve(); // Resolve no sucesso
            };

            if (element instanceof HTMLMediaElement) {
                if (element.readyState >= 2) { // HAVE_CURRENT_DATA
                    resolve();
                } else {
                    element.addEventListener('loadeddata', onLoad, {once: true});
                    element.addEventListener('error', onError, {once: true});
                    element.load();
                }
            } else if (element instanceof HTMLImageElement) {
                if (element.complete) {
                    resolve();
                } else {
                    element.onload = onLoad;
                    element.onerror = onError;
                    // Se a imagem ainda não está na DOM, mario.src/pipe.src etc. já a carregam.
                    // Mas para garantir, podemos criar um objeto Image:
                    const tempImg = new Image();
                    tempImg.src = element.src;
                }
            } else {
                resolve();
            }
        });
    };

    // Adiciona Promises para todos os recursos importantes
    resourcePromises.push(loadResource(audioTheme));
    resourcePromises.push(loadResource(audioGameOver));
    resourcePromises.push(loadResource(audioJump));

    // Criando objetos Image para garantir que as imagens sejam carregadas
    const marioImg = new Image(); marioImg.src = 'img/mario.gif';
    resourcePromises.push(loadResource(marioImg));
    
    const pipeImg = new Image(); pipeImg.src = 'img/pipe.png';
    resourcePromises.push(loadResource(pipeImg));

    const cloudsImg = new Image(); cloudsImg.src = 'img/clouds.png';
    resourcePromises.push(loadResource(cloudsImg));

    const gameOverImg = new Image(); gameOverImg.src = 'img/game-over.png';
    resourcePromises.push(loadResource(gameOverImg));


    // Espera por todas as Promises de recursos e pelo tempo mínimo
    Promise.all(resourcePromises).finally(() => {
        const endTime = Date.now();
        const timeToWait = minLoadingTime - (endTime - startTime);

        setTimeout(() => {
            // Esconde a tela de carregamento
            loadingScreen.style.opacity = '0';
            // Usa setTimeout para remover display: none, garantindo que a transição ocorra
            setTimeout(() => {
                loadingScreen.style.display = 'none'; 
            }, 500); // tempo da transição de opacidade

            // Revela o jogo
            gameContainer.style.opacity = '1';
            gameContainer.style.pointerEvents = 'auto'; // Permite interação
            
            // Inicia o jogo APÓS o carregamento e a transição
            const usuarioLogado = JSON.parse(localStorage.getItem('usuarioLogado'));
            if (usuarioLogado && usuarioLogado.nick) {
                playerNickSpan.textContent = usuarioLogado.nick;
            } else {
                alert('Você precisa estar logado para jogar!');
                window.location.href = '../login.html';
                return;
            }
        }, Math.max(0, timeToWait));
    }).catch(error => {
        console.error("Erro ao carregar recursos do jogo:", error);
        alert("Erro grave ao carregar o jogo. Por favor, tente novamente.");
        window.location.href = '../jogos.html';
    });
});