// Função para detectar dispositivo móvel
function isMobile() {
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}

// Função para aplicar classe no body conforme escolha salva
function aplicarClasseDispositivo() {
  const userDevice = localStorage.getItem('userDevice');
  if (userDevice === 'celular') {
    document.body.classList.add('mobile');
    document.body.classList.remove('desktop');
  } else if (userDevice === 'pc') {
    document.body.classList.add('desktop');
    document.body.classList.remove('mobile');
  } else {
    document.body.classList.add('desktop');
  }
}

window.addEventListener('load', () => {
  aplicarClasseDispositivo();

  // Se quiser mostrar o modal só na primeira página, controle aqui
  if (!localStorage.getItem('userDevice')) {
    // Código para mostrar modal da quest, ou redirecionar para página inicial
    // Ou você pode criar um modal global que aparece em todas as páginas
  }
});
