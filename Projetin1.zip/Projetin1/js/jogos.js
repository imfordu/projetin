  // Pega o nick do localStorage e coloca na tela
    document.getElementById('nick').textContent = localStorage.getItem('nick') || 'Visitante';