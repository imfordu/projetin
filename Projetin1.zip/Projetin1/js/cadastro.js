    // Se já tiver nick salvo, redireciona direto para jogos
    window.onload = () => {
      if (localStorage.getItem('nick')) {
        window.location.href = 'jogos.html';
      }
    };


  // Inicialize o cliente Supabase
  const supabaseUrl = 'https://afmypqrrvmqijzanqfzf.supabase.co'; // substitua pela sua URL
  const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFmbXlwcXJydm1xaWp6YW5xZnpmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg1NDQzNzQsImV4cCI6MjA2NDEyMDM3NH0.EwVIKeZ8PH-E7bYZd5dtkiBsC3ZIGmZCmYSOgnhciIc'; // substitua pela sua chave anon public
  const supabase = supabase.createClient(supabaseUrl, supabaseKey);

  // Função para cadastrar usuário
  async function cadastrar(nick) {
    const { data, error } = await supabase
      .from('users')
      .insert([{ nick }]);
    if (error) {
      alert('Erro ao cadastrar: ' + error.message);
      return false;
    }
    alert('Cadastro realizado com sucesso!');
    return true;
  }

  // Função para validar login
  async function login(nick) {
    const { data, error } = await supabase
      .from('users')
      .select()
      .eq('nick', nick)
      .limit(1)
      .single();

    if (error || !data) {
      alert('Nick não encontrado. Você será redirecionado para cadastro.');
      window.location.href = 'cadastro.html';
      return false;
    }
    alert('Bem-vindo, ' + data.nick + '!');
    // redirecione para a página principal, por exemplo
    return true;
  }

