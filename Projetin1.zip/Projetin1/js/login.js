

    // Se já estiver "logado", vai direto para jogos.html
    window.onload = () => {
      if (localStorage.getItem('nick')) {
        window.location.href = 'jogos.html';
      }
    };

    function login(event) {
      event.preventDefault(); // Evita o envio padrão do formulário

      const nickInput = document.getElementById('nick');
      const nick = nickInput.value.trim();

      if (nick.length > 0) {
        localStorage.setItem('nick', nick);
        window.location.href = 'jogos.html'; // Vai para página de jogos
      } else {
        alert('Por favor, digite seu nick!');
      }
      return false;
    }

    function login(event) {
  event.preventDefault();
  const nick = document.getElementById('nick').value;
  localStorage.setItem('nick', nick); // Salva o nick no navegador
  window.location.href = 'jogos.html'; // Redireciona para a página de boas-vindas
  return false;
}