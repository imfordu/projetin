// --- Elementos do DOM ---
const gameContainer = document.querySelector('.game-container');
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d'); // Certifique-se que ctx está pegando o contexto 2D

// Usando o ID 'tela-carregamento' para consistência com a página principal
const loadingScreen = document.getElementById('tela-carregamento'); 
const startScreen = document.getElementById('start-screen');
const gameOverScreen = document.getElementById('game-over-screen');

const startButton = document.getElementById('start-btn');
const restartButton = document.getElementById('restart-btn');

const playerNickSpan = document.getElementById('player-nick');
const currentScoreSpan = document.getElementById('current-score');
const gameTimeSpan = document.getElementById('game-time');
const highScoreDisplay = document.getElementById('high-score-display');
const finalScoreDisplay = document = document.getElementById('final-score'); // CORRIGIDO AQUI
const finalTimeDisplay = document.getElementById('final-time');
const gameOverHighScoreDisplay = document.getElementById('gameover-high-score');

const upButton = document.getElementById('upButton');
const downButton = document.getElementById('downButton');
const leftButton = document.getElementById('leftButton');
const rightButton = document.getElementById('rightButton');

// Áudios - certifique-se que os caminhos e arquivos .mp3 existem na pasta sounds/
const audioPickup = document.getElementById('audio-pickup');
const audioGameover = document.getElementById('audio-gameover');
const audioClick = document.getElementById('audio-click'); // Áudio do clique global (../sounds/click.mp3)
const audioTheme = document.getElementById('audio-theme'); // Música tema do jogo

// --- Variáveis do Jogo ---
let gridSize = 25; // Tamanho de cada célula do grid em pixels
let tileCount = 25; // Número de tiles por linha/coluna (25x25)

let snake = [{ x: 10, y: 10 }]; // Posição inicial da cobra
let food = {}; // Posição da maçã
let direction = 'right'; // Direção inicial da cobra
let changingDirection = false; // Flag para evitar múltiplas mudanças de direção por frame
let score = 0; // Pontuação atual do jogo
let animationFrameId; // ID do requestAnimationFrame para controlar o loop do jogo
let gameSpeed = 150; // Velocidade do jogo em milissegundos por movimento (maior = mais lento, mais fácil)
let lastMoveTime = 0; // Tempo do último movimento da cobra para controle de velocidade
let gameTimerInterval; // Intervalo para o cronômetro de jogo
let gameSeconds = 0; // Segundos passados no jogo
let animationFrameCounter = 0; // Contador de frames para animações visuais do canvas

// Obstáculos: Bugs fixos no tabuleiro
const obstacles = [ 
    { x: 5, y: 5 }, { x: 19, y: 5 }, { x: 5, y: 19 }, { x: 19, y: 19 }, // 4 cantos
    { x: 12, y: 2 }, { x: 12, y: 22 }, { x: 2, y: 12 }, { x: 22, y: 12 }  // Meio de bordas
];

// --- Funções Auxiliares de UI/Tempo ---

/**
 * Formata um número total de segundos para o formato MM:SS.
 * @param {number} totalSeconds - O número total de segundos.
 * @returns {string} Tempo formatado (MM:SS).
 */
function formatTime(totalSeconds) {
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

/**
 * Atualiza o cronômetro do jogo na interface.
 */
function updateGameTime() {
    gameSeconds++;
    gameTimeSpan.textContent = formatTime(gameSeconds);
}

// --- Funções de Desenho (Canvas) - AGORA BÁSICAS E TRADICIONAIS ---

/**
 * Desenha um segmento da cobra como um quadrado sólido.
 */
function drawSnake() {
    snake.forEach((segment, index) => {
        const x = segment.x * gridSize;
        const y = segment.y * gridSize;
        
        ctx.fillStyle = 'var(--snake-body-color)'; // Cor verde para o corpo
        ctx.strokeStyle = 'rgba(0, 0, 0, 0.2)'; // Borda sutil para separar segmentos
        ctx.lineWidth = 1;

        ctx.fillRect(x, y, gridSize, gridSize);
        ctx.strokeRect(x, y, gridSize, gridSize);

        // Cabeça da cobra: ligeiramente diferente para indicar a frente
        if (index === 0) {
            ctx.fillStyle = 'var(--snake-head-color)'; // Cor branca para a cabeça
            ctx.beginPath();
            ctx.arc(x + gridSize / 2, y + gridSize / 2, gridSize * 0.25, 0, 2 * Math.PI);
            ctx.fill();
        }
    });
}

/**
 * Desenha a Maçã como um círculo vermelho sólido.
 */
function drawFood() {
    if (!food || typeof food.x === 'undefined') { 
        // console.warn("Comida não gerada ainda ou inválida."); // DEBUG
        return; 
    }

    const x = food.x * gridSize;
    const y = food.y * gridSize;
    const centerX = x + gridSize / 2;
    const centerY = y + gridSize / 2;
    const radius = gridSize * 0.4;

    ctx.fillStyle = 'var(--food-color)'; // Cor da maçã (vermelha sólida)
    // Removemos sombras e brilhos complexos para um visual básico
    // ctx.shadowColor = 'var(--food-color)'; 
    // ctx.shadowBlur = 15; 
    
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
    ctx.fill();
    // ctx.shadowBlur = 0; // Resetar shadow se usado
}

/**
 * Desenha um Bug (obstáculo) como um quadrado sólido.
 */
function drawObstacle(ox, oy) { 
    const x = ox * gridSize;
    const y = oy * gridSize;
    
    ctx.fillStyle = 'var(--obstacle-color)'; // Cor do obstáculo (cinza escuro)
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.5)'; // Borda sutil
    ctx.lineWidth = 1;
    
    ctx.fillRect(x, y, gridSize, gridSize);
    ctx.strokeRect(x, y, gridSize, gridSize);
}

// --- Lógica do Jogo ---

/**
 * Gera uma nova posição para a comida, garantindo que não esteja na cobra ou em um obstáculo.
 */
function generateFood() {
    const maxGridX = tileCount;
    const maxGridY = tileCount;

    let validPosition = false;
    while (!validPosition) {
        food = {
            x: Math.floor(Math.random() * maxGridX),
            y: Math.floor(Math.random() * maxGridY)
        };
        const onSnake = snake.some(seg => seg.x === food.x && seg.y === food.y);
        const onObstacle = obstacles.some(obs => obs.x === food.x && obs.y === food.y);
        if (!onSnake && !onObstacle) {
            validPosition = true;
        }
    }
}

/**
 * Atualiza a posição da cobra a cada frame, verifica colisões e pontuação.
 */
function moveSnake() {
    const head = { x: snake[0].x, y: snake[0].y };
    const maxGridX = tileCount;
    const maxGridY = tileCount;

    switch (direction) {
        case 'up': head.y--; break;
        case 'down': head.y++; break;
        case 'left': head.x--; break;
        case 'right': head.x++; break;
    }

    const hitWall = head.x < 0 || head.x >= maxGridX || head.y < 0 || head.y >= maxGridY;
    const hitSelf = snake.slice(1).some(segment => segment.x === head.x && segment.y === head.y);
    const hitObstacle = obstacles.some(obstacle => obstacle.x === head.x && obstacle.y === head.y); 

    if (hitWall || hitSelf || hitObstacle) { 
        endGame();
        return;
    }

    snake.unshift(head);

    if (head.x === food.x && head.y === food.y) {
        score += 10;
        currentScoreSpan.textContent = score;
        audioPickup.play().catch(e => console.warn("Erro ao tocar áudio de coleta:", e));
        generateFood();
        if (gameSpeed > 50) gameSpeed -= 3;
    } else {
        snake.pop();
    }
    changingDirection = false;
}

/**
 * Loop principal do jogo, executado a cada frame com requestAnimationFrame.
 * @param {DOMHighResTimeStamp} currentTime - Tempo atual fornecido pelo requestAnimationFrame.
 */
function gameLoop(currentTime) {
    animationFrameId = requestAnimationFrame(gameLoop);

    const timeSinceLastMove = currentTime - lastMoveTime;
    if (timeSinceLastMove > gameSpeed) {
        lastMoveTime = currentTime;
        moveSnake();
    }
    
    ctx.clearRect(0, 0, canvas.width, canvas.height); // Limpa o canvas
    drawBackgroundGrid(); // Desenha o grid de fundo
    obstacles.forEach(obs => drawObstacle(obs.x, obs.y)); // Desenha obstáculos
    drawFood(); // Desenha a comida
    drawSnake(); // Desenha a cobra
    
    animationFrameCounter++; // Incrementa para animações
}

/**
 * Desenha um grid de fundo simples e básico no canvas.
 */
function drawBackgroundGrid() {
    const cols = tileCount;
    const rows = tileCount;
    ctx.fillStyle = 'var(--canvas-background-color)'; // Fundo azul básico
    ctx.fillRect(0, 0, canvas.width, canvas.height); // Preenche o canvas com a cor de fundo

    ctx.strokeStyle = 'var(--grid-line-color)'; // Linhas brancas sutis para o grid
    ctx.lineWidth = 1;

    for (let i = 0; i <= cols; i++) {
        ctx.beginPath();
        ctx.moveTo(i * gridSize, 0);
        ctx.lineTo(i * gridSize, canvas.height);
        ctx.stroke();
    }

    for (let i = 0; i <= rows; i++) {
        ctx.beginPath();
        ctx.moveTo(0, i * gridSize);
        ctx.lineTo(canvas.width, i * gridSize);
        ctx.stroke();
    }
    // REMOVIDOS COMPLETAMENTE: Efeitos de pulso nos nós e linhas de código de fundo.
}


/**
 * Inicia o jogo, resetando estados e exibindo a tela de jogo.
 */
function startGame() {
    audioClick.play().catch(e => console.warn("Erro ao tocar áudio de clique:", e));
    
    startScreen.style.opacity = '0';
    startScreen.style.visibility = 'hidden';
    gameOverScreen.style.display = 'none';

    snake = [{ x: Math.floor(tileCount / 2), y: Math.floor(tileCount / 2) }];
    direction = 'right';
    score = 0;
    currentScoreSpan.textContent = score;
    gameSeconds = 0;
    gameTimeSpan.textContent = '00:00';
    gameSpeed = 150;

    generateFood(); // Garante que a comida seja gerada no início
    
    // Inicia o gameLoop SOMENTE AQUI
    cancelAnimationFrame(animationFrameId);
    clearInterval(gameTimerInterval);
    
    lastMoveTime = performance.now();
    animationFrameId = requestAnimationFrame(gameLoop);
    gameTimerInterval = setInterval(updateGameTime, 1000);

    audioTheme.currentTime = 0;
    audioTheme.play().catch(e => console.warn("Erro ao tocar música tema:", e));
}

/**
 * Encerra o jogo (Game Over) e exibe a tela de resultados.
 */
function endGame() {
    cancelAnimationFrame(animationFrameId);
    clearInterval(gameTimerInterval);
    animationFrameId = null;

    audioGameover.play().catch(e => console.warn("Erro ao tocar áudio de Game Over:", e));
    audioTheme.pause();
    audioTheme.currentTime = 0;

    finalScoreDisplay.textContent = score;
    finalTimeDisplay.textContent = formatTime(gameSeconds);

    saveGameStats(score);
    loadGameStats();

    gameOverScreen.style.display = 'flex';
    setTimeout(() => {
        gameOverScreen.style.opacity = '1';
        gameOverScreen.style.visibility = 'visible';
    }, 50);
}

/**
 * Reinicia o jogo após o Game Over.
 */
function restartGame() {
    audioClick.play().catch(e => console.warn("Erro ao tocar áudio de clique:", e));
    
    gameOverScreen.style.opacity = '0';
    gameOverScreen.style.visibility = 'hidden';
    
    setTimeout(startGame, 500);
}

// --- Gerenciamento de Dados (Local Storage) ---
/**
 * Salva a pontuação atual e a melhor pontuação no Local Storage.
 * @param {number} currentScore - A pontuação alcançada no jogo.
 */
function saveGameStats(currentScore) {
    const usuarioLogado = JSON.parse(localStorage.getItem('usuarioLogado'));
    const currentPlayer = usuarioLogado ? usuarioLogado.nick : 'Visitante';
    
    let gameStats = JSON.parse(localStorage.getItem('codigoFonteStats')) || { highScore: 0, lastPlayer: 'N/A' };
    
    if (currentScore > gameStats.highScore) {
        gameStats.highScore = currentScore;
        gameStats.lastPlayer = currentPlayer;
    }
    localStorage.setItem('codigoFonteStats', JSON.stringify(gameStats));
}

/**
 * Carrega as estatísticas do jogo (nome do jogador e melhor pontuação) do Local Storage
 * e as exibe na interface.
 */
function loadGameStats() {
    const usuarioLogado = JSON.parse(localStorage.getItem('usuarioLogado'));
    const currentPlayer = usuarioLogado ? usuarioLogado.nick : 'Visitante';
    
    const gameStats = JSON.parse(localStorage.getItem('codigoFonteStats')) || { highScore: 0, lastPlayer: 'N/A' };
    
    playerNickSpan.textContent = currentPlayer;
    highScoreDisplay.textContent = gameStats.highScore;
    gameOverHighScoreDisplay.textContent = gameStats.highScore;
}

// --- Inicialização e Eventos Globais ---
/**
 * Ajusta o tamanho do canvas para preencher o container e mantém a proporção da grade.
 */
function adjustCanvasSize() {
    const size = Math.min(gameContainer.clientWidth, gameContainer.clientHeight);
    canvas.width = size;
    canvas.height = size;
    gridSize = size / tileCount;
    // Forçar um redesenho inicial após o ajuste
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawBackgroundGrid();
    drawFood(); // Desenha a comida após o ajuste de tamanho
    drawSnake(); // Desenha a cobra após o ajuste de tamanho
}

document.addEventListener('DOMContentLoaded', () => {
    const minLoadingTime = 3000;
    const startTime = Date.now();

    const loadResource = (element) => {
        return new Promise(resolve => {
            const onError = () => {
                console.error(`Erro ao carregar recurso: ${element.src || element.id || 'Elemento desconhecido'}`);
                resolve();
            };
            const onLoad = () => {
                resolve();
            };

            if (element instanceof HTMLMediaElement) {
                if (element.readyState >= 2) {
                    resolve();
                } else {
                    element.addEventListener('loadeddata', onLoad, {once: true});
                    element.addEventListener('error', onError, {once: true});
                    element.load();
                }
            } else if (element instanceof HTMLImageElement) {
                if (element.complete) {
                    resolve();
                } else {
                    element.onload = onLoad;
                    element.onerror = onError;
                    if (!element.src && element.dataset.src) { 
                        element.src = element.dataset.src;
                    }
                }
            } else {
                resolve();
            }
        });
    };

    const resourcePromises = [
        loadResource(audioPickup),
        loadResource(audioGameover),
        loadResource(audioClick),
        loadResource(audioTheme),
    ];

    Promise.all(resourcePromises).finally(() => {
        const elapsedTime = Date.now() - startTime;
        const timeToWait = Math.max(0, minLoadingTime - elapsedTime);
        
        setTimeout(() => {
            loadingScreen.style.opacity = '0';
            setTimeout(() => {
                loadingScreen.style.visibility = 'hidden';
                loadingScreen.style.display = 'none';
                document.body.classList.add('loaded');
                adjustCanvasSize(); // Garante que o canvas seja redimensionado e redesenhado após o loading
            }, 500);
        }, timeToWait);
    }).catch(error => {
        console.error("Erro ao carregar recursos do jogo:", error);
        alert("Erro grave ao carregar o jogo. Por favor, tente novamente.");
        window.location.href = '../jogos.html';
    });
    
    adjustCanvasSize(); // Ajusta o tamanho do canvas na carga inicial (antes do loading sumir)
    loadGameStats();

    startButton.addEventListener('click', startGame);
    restartButton.addEventListener('click', restartGame);

    document.addEventListener('keydown', e => {
        if (changingDirection || !animationFrameId) return;
        changingDirection = true;
        const keyPressed = e.key.toLowerCase();
        
        // IMPEDIR VIRA 180 GRAUS (CORREÇÃO DE LÓGICA + TECLAS)
        if ((keyPressed === 'arrowleft' || keyPressed === 'a') && direction !== 'right') {
            direction = 'left';
        } else if ((keyPressed === 'arrowup' || keyPressed === 'w') && direction !== 'down') { // CORRIGIDO: 'w' para 'up'
            direction = 'up';
        } else if ((keyPressed === 'arrowright' || keyPressed === 'd') && direction !== 'left') {
            direction = 'right';
        } else if ((keyPressed === 'arrowdown' || keyPressed === 's') && direction !== 'up') {
            direction = 'down';
        }
    });

    upButton.addEventListener('click', () => { 
        if (animationFrameId && direction !== 'down') { 
            direction = 'up'; 
            audioClick.play().catch(e => console.warn("Erro ao tocar clique:", e)); 
        } 
    });
    downButton.addEventListener('click', () => { 
        if (animationFrameId && direction !== 'up') { 
            direction = 'down'; 
            audioClick.play().catch(e => console.warn("Erro ao tocar clique:", e)); 
        } 
    });
    leftButton.addEventListener('click', () => { 
        if (animationFrameId && direction !== 'right') { 
            direction = 'left'; 
            audioClick.play().catch(e => console.warn("Erro ao tocar clique:", e)); 
        } 
    });
    rightButton.addEventListener('click', () => { 
        if (animationFrameId && direction !== 'left') { 
            direction = 'right'; 
            audioClick.play().catch(e => console.warn("Erro ao tocar clique:", e)); 
        } 
    });

    window.addEventListener('resize', adjustCanvasSize);

});