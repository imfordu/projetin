   (() => {
      const form = document.getElementById('form');
      const itemInput = document.getElementById('itemInput');
      const qtyInput = document.getElementById('qtyInput');
      const shoppingList = document.getElementById('shoppingList');
      const emptyMessage = document.getElementById('emptyMessage');
      const filterButtons = document.querySelectorAll('.filters button');
      const sortButtons = document.querySelectorAll('.sorters button');
      const counter = document.querySelector('.counter');
      const exportBtn = document.getElementById('exportBtn');
      const importBtn = document.getElementById('importBtn');
      const fileInput = document.getElementById('fileInput');

      let items = [];
      let currentFilter = 'all';
      let currentSort = 'default';

      function loadItems() {
        const saved = localStorage.getItem('shoppingItems');
        if(saved) {
          try {
            items = JSON.parse(saved);
            if(!Array.isArray(items)) items = [];
          } catch {
            items = [];
          }
        }
      }

      function saveItems() {
        localStorage.setItem('shoppingItems', JSON.stringify(items));
      }

      function generateId() {
        return '_' + Math.random().toString(36).substr(2, 9);
      }

      function renderList() {
        shoppingList.innerHTML = '';

        let filtered = items;
        switch(currentFilter) {
          case 'pending':
            filtered = items.filter(i => !i.completed);
            break;
          case 'completed':
            filtered = items.filter(i => i.completed);
            break;
        }

        switch(currentSort) {
          case 'alpha':
            filtered = [...filtered].sort((a,b) => a.text.localeCompare(b.text));
            break;
          case 'status':
            filtered = [...filtered].sort((a,b) => a.completed - b.completed);
            break;
        }

        if(filtered.length === 0) {
          emptyMessage.hidden = false;
          counter.textContent = '';
          return;
        } else {
          emptyMessage.hidden = true;
        }

        filtered.forEach(item => {
          const li = document.createElement('li');
          li.className = 'item';
          li.dataset.id = item.id;

          const textSpan = document.createElement('span');
          textSpan.className = 'item-text';
          textSpan.textContent = item.text;
          textSpan.tabIndex = 0;
          textSpan.title = 'Clique para editar o nome do item';
          if(item.completed) textSpan.classList.add('completed');
          textSpan.setAttribute('aria-label', `Item: ${item.text}, ${item.completed ? 'comprado' : 'pendente'}`);
          textSpan.setAttribute('role', 'textbox');
          textSpan.setAttribute('contenteditable', 'false');
          textSpan.spellcheck = false;

          const qtySpan = document.createElement('span');
          qtySpan.className = 'item-qty';
          qtySpan.textContent = `x${item.quantity}`;
          qtySpan.title = 'Clique para editar a quantidade';
          if(item.completed) qtySpan.classList.add('completed');
          qtySpan.tabIndex = 0;
          qtySpan.setAttribute('aria-label', `Quantidade: ${item.quantity}`);
          qtySpan.setAttribute('role', 'spinbutton');
          qtySpan.setAttribute('contenteditable', 'false');
          qtySpan.spellcheck = false;

          const btnGroup = document.createElement('div');
          btnGroup.className = 'btn-group';

          const checkBtn = document.createElement('button');
          checkBtn.className = 'btn check-btn';
          checkBtn.title = item.completed ? 'Marcar como pendente' : 'Marcar como comprado';
          checkBtn.setAttribute('aria-label', checkBtn.title);
          checkBtn.innerHTML = item.completed ? '&#x2713;' : '&#x2610;';
          checkBtn.addEventListener('click', () => toggleCompleted(item.id));

          const editBtn = document.createElement('button');
          editBtn.className = 'btn edit-btn';
          editBtn.title = 'Editar item';
          editBtn.setAttribute('aria-label', 'Editar item');
          editBtn.innerHTML = '&#9998;';
          editBtn.addEventListener('click', () => enableEditing(textSpan, qtySpan, editBtn));

          const removeBtn = document.createElement('button');
          removeBtn.className = 'btn remove-btn';
          removeBtn.title = 'Remover item';
          removeBtn.setAttribute('aria-label', `Remover item ${item.text}`);
          removeBtn.innerHTML = '&#10005;';
          removeBtn.addEventListener('click', () => removeItem(item.id, li));

          btnGroup.append(checkBtn, editBtn, removeBtn);

          li.append(textSpan, qtySpan, btnGroup);
          shoppingList.appendChild(li);
        });

        updateCounter();
      }

      function updateCounter() {
        const total = items.length;
        const completed = items.filter(i => i.completed).length;
        const pending = total - completed;
        counter.textContent = `Total: ${total} | Pendentes: ${pending} | Comprados: ${completed}`;
      }

      function addItem(text, quantity) {
        if(!text || text.trim() === '') {
          alert('Por favor, digite o nome do item.');
          return false;
        }
        if(quantity < 1 || quantity > 999) {
          alert('Quantidade deve ser entre 1 e 999.');
          return false;
        }
        const exists = items.some(i => i.text.toLowerCase() === text.toLowerCase() && !i.completed);
        if(exists) {
          alert('Este item já está na lista como pendente!');
          return false;
        }
        items.push({
          id: generateId(),
          text: text.trim(),
          quantity,
          completed: false
        });
        saveItems();
        renderList();
        return true;
      }

      function removeItem(id, li) {
        if(!li) {
          li = document.querySelector(`li.item[data-id="${id}"]`);
          if(!li) return;
        }
        if(confirm(`Tem certeza que deseja remover o item "${li.querySelector('.item-text').textContent}"?`)) {
          li.classList.add('removing');
          li.addEventListener('animationend', () => {
            items = items.filter(i => i.id !== id);
            saveItems();
            renderList();
          }, { once: true });
        }
      }

      function toggleCompleted(id) {
        const item = items.find(i => i.id === id);
        if(!item) return;
        item.completed = !item.completed;
        saveItems();
        renderList();
      }

      function enableEditing(textSpan, qtySpan, editBtn) {
        if(textSpan.isContentEditable) {
          const li = textSpan.closest('li');
          const id = li.dataset.id;
          const item = items.find(i => i.id === id);
          if(!item) return;

          let newText = textSpan.textContent.trim();
          if(newText === '') {
            alert('O nome do item não pode ficar vazio.');
            textSpan.textContent = item.text;
            disableEditing(textSpan, qtySpan, editBtn);
            return;
          }
          let newQty = parseInt(qtySpan.textContent.replace(/[^\d]/g, ''), 10);
          if(isNaN(newQty) || newQty < 1 || newQty > 999) {
            alert('Quantidade inválida. Deve ser entre 1 e 999.');
            qtySpan.textContent = `x${item.quantity}`;
            disableEditing(textSpan, qtySpan, editBtn);
            return;
          }
          const duplicate = items.some(i => i.id !== id && i.text.toLowerCase() === newText.toLowerCase() && !i.completed);
          if(duplicate) {
            alert('Já existe um item pendente com esse nome.');
            textSpan.textContent = item.text;
            disableEditing(textSpan, qtySpan, editBtn);
            return;
          }

          item.text = newText;
          item.quantity = newQty;
          saveItems();
          disableEditing(textSpan, qtySpan, editBtn);
          renderList();
        } else {
          textSpan.contentEditable = 'true';
          qtySpan.contentEditable = 'true';
          textSpan.focus();
          editBtn.innerHTML = '&#10003;';
          editBtn.title = 'Salvar edição';
          document.execCommand('selectAll', false, null);
          textSpan.addEventListener('keydown', preventNewLine);
          qtySpan.addEventListener('keydown', preventNewLine);
        }
      }

      function disableEditing(textSpan, qtySpan, editBtn) {
        textSpan.contentEditable = 'false';
        qtySpan.contentEditable = 'false';
        editBtn.innerHTML = '&#9998;';
        editBtn.title = 'Editar item';
        textSpan.removeEventListener('keydown', preventNewLine);
        qtySpan.removeEventListener('keydown', preventNewLine);
      }

      function preventNewLine(e) {
        if(e.key === 'Enter') {
          e.preventDefault();
          e.target.blur();
        }
      }

      function exportJSON() {
        if(items.length === 0) {
          alert('A lista está vazia, nada para exportar.');
          return;
        }
        const dataStr = JSON.stringify(items, null, 2);
        const blob = new Blob([dataStr], {type: "application/json"});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'lista-compras.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }

      function importJSON(file) {
        if(!file) return;
        const reader = new FileReader();
        reader.onload = (e) => {
          try {
            const imported = JSON.parse(e.target.result);
            if(!Array.isArray(imported)) throw new Error('Arquivo inválido');
            const valid = imported.every(i => i.id && typeof i.text === 'string' && typeof i.quantity === 'number' && typeof i.completed === 'boolean');
            if(!valid) throw new Error('Estrutura do arquivo inválida');
            if(confirm('Deseja substituir a lista atual pela lista importada? Isso apagará os dados atuais.')) {
              items = imported;
              saveItems();
              renderList();
              alert('Lista importada com sucesso!');
            }
          } catch (err) {
            alert('Erro ao importar arquivo: ' + err.message);
          }
        };
        reader.readAsText(file);
      }

      filterButtons.forEach(btn => {
        btn.addEventListener('click', () => {
          filterButtons.forEach(b => {
            b.classList.remove('active');
            b.setAttribute('aria-pressed', 'false');
          });
          btn.classList.add('active');
          btn.setAttribute('aria-pressed', 'true');
          currentFilter = btn.dataset.filter;
          renderList();
        });
      });

      sortButtons.forEach(btn => {
        btn.addEventListener('click', () => {
          sortButtons.forEach(b => {
            b.classList.remove('active');
            b.setAttribute('aria-pressed', 'false');
          });
          btn.classList.add('active');
          btn.setAttribute('aria-pressed', 'true');
          currentSort = btn.dataset.sort;
          renderList();
        });
      });

      form.addEventListener('submit', e => {
        e.preventDefault();
        const text = itemInput.value;
        const qty = parseInt(qtyInput.value, 10) || 1;
        if(addItem(text, qty)) {
          form.reset();
          qtyInput.value = '1';
          itemInput.focus();
        }
      });

      exportBtn.addEventListener('click', exportJSON);
      importBtn.addEventListener('click', () => fileInput.click());
      fileInput.addEventListener('change', () => {
        if(fileInput.files.length > 0) {
          importJSON(fileInput.files[0]);
          fileInput.value = '';
        }
      });

      loadItems();
      renderList();
    })();